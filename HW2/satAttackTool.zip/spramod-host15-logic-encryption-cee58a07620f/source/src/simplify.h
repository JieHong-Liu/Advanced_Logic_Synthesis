#ifndef _SIMPLIFY_H_DEFINED_
#define _SIMPLIFY_H_DEFINED_

int simplify_main(int argc, char* argv[]);

#endif // _SIMPLIFY_H_DEFINED_
